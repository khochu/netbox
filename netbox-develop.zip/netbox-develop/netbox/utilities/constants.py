from utilities.forms import ChainedModelMultipleChoiceField


# Fields which are used on ManyToMany relationships
M2M_FIELD_TYPES = [
    ChainedModelMultipleChoiceField,
]
