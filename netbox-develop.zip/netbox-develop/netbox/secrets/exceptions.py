from __future__ import unicode_literals


class InvalidKey(Exception):
    """
    Raised when a provided key is invalid.
    """
    pass
